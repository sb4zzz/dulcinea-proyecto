// ------------------- CONFIG -------------------
const API = "http://192.168.10.16:5000";

const idKeyMap = {
  disqueras: "disquera_id",
  solistas: "solista_id",
  bandas: "banda_id",
  albumes: "album_id",
  canciones: "cancion_id",
  eventos: "evento_id",
  contratos: "contrato_id",
  turnos: "turno_id"
};

const columnOrder = {
  disqueras: ["disquera_id","nombre","ciudad_sede","telefono"],
  solistas: ["solista_id","nombre","apellido","nombre_artistico","sexo","fecha_nacimiento","ciudad_nacimiento","inicio_carrera"],
  bandas: ["banda_id","nombre","anio_formacion","num_integrantes","representante"],
  albumes: ["album_id","disquera_id","solista_id","banda_id","titulo","anio","genero","duracion_total"],
  canciones: ["cancion_id","album_id","titulo","duracion_seconds","idioma"],
  eventos: ["evento_id","nombre","fecha","lugar","horario_inicio","horario_fin"],
  contratos: ["contrato_id","solista_id","banda_id","disquera_id","fecha_inicio","fecha_fin","condiciones"],
  turnos: ["turno_id","evento_id","solista_id","banda_id","orden_presentacion","lugar","fecha","hora_inicio","hora_fin"]
};

// ------------------- PESTAÑAS -------------------
const tabs = document.querySelectorAll(".tab");
const contents = document.querySelectorAll(".content");
tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    contents.forEach(c => c.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(tab.dataset.target).classList.add("active");
  });
});

// ------------------- DURACIÓN -------------------
function parseSongDuration(input) {
  let parts = input.split(":").map(Number);
  let totalSeconds = parts.length===2 ? parts[0]*60 + parts[1] : parts[0]*3600 + parts[1]*60 + parts[2];
  if(totalSeconds > 600) throw new Error("La duración máxima es 10 minutos");
  return totalSeconds;
}

function formatDurationString(value) {
  if (!value) return "";
  if (typeof value === "string" && value.includes(":")) {
    // ya viene como HH:MM:SS desde el backend
    return value.length === 5 ? `00:${value}` : value;
  }
  // si viniera en segundos
  const min = Math.floor(value / 60);
  const sec = value % 60;
  return `${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

// ------------------- FETCH Y RENDER -------------------
async function fetchAndRender(endpoint, tableId) {
  try {
    const res = await fetch(`${API}/${endpoint}`);
    const data = await res.json();
    const table = document.getElementById(`table-${tableId}`);

    if (!Array.isArray(data) || data.length === 0) {
      table.innerHTML = "<tr><td>No hay registros</td></tr>";
      return;
    }

    const headers = columnOrder[endpoint] || Object.keys(data[0]);
    const idKey = idKeyMap[endpoint];

    table.innerHTML = `
      <tr>${headers.map(h => `<th>${h}</th>`).join("")}<th>Acciones</th></tr>
      ${data.map(row => `
        <tr>
          ${headers.map(h => {
            let value = row[h];
            // formatear duración de canciones y álbumes
            if (h === "duracion_seconds" && value != null) value = formatDurationString(value);
            if (h === "duracion_total" && value != null) value = formatDurationString(value);
            return `<td>${value !== null ? value : ""}</td>`;
          }).join("")}
          <td>
            ${
              endpoint !== "turnos"
                ? `<button class='btn btn-edit' onclick="editRecord('${endpoint}', ${row[idKey]})">Editar</button>
                   <button class='btn btn-delete' onclick="deleteRecord('${endpoint}', ${row[idKey]})">Eliminar</button>`
                : `<button class='btn btn-edit' disabled style="opacity:0.5;">Bloqueado</button>`
            }
          </td>
        </tr>`).join("")}
    `;
  } catch (err) {
    console.error("Error cargando datos:", err);
    document.getElementById(`table-${tableId}`).innerHTML = "<tr><td>Error cargando datos</td></tr>";
  }
}

// ------------------- CREAR -------------------
async function setupForm(formId, endpoint) {
  const form = document.getElementById(formId);
  form.addEventListener("submit", async e => {
    e.preventDefault();
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Campos numéricos
    ['anio_formacion','num_integrantes','disquera_id','solista_id','banda_id','orden_presentacion','evento_id','anio','album_id'].forEach(f => {
      if (data[f]) data[f] = parseInt(data[f]);
    });

    // Validaciones
    if (endpoint === "solistas" && data.fecha_nacimiento && data.inicio_carrera) {
      if (new Date(data.inicio_carrera) < new Date(data.fecha_nacimiento)) 
        return alert("❌ La fecha de inicio de carrera no puede ser menor que la fecha de nacimiento.");
    }

    if (endpoint === "albumes") {
      if (data.solista_id && data.banda_id)
        return alert("❌ Un álbum no puede pertenecer a solista y banda a la vez");
     if (!data.solista_id && !data.banda_id)
       return alert("❌ El álbum debe pertenecer a solista o banda");
    }

    if (endpoint === "canciones" && data.duracion_seconds) {
      try { data.duracion_seconds = parseSongDuration(data.duracion_seconds); }
      catch(e){ return alert(`❌ ${e.message}`); }
    }

    if (endpoint === "contratos") {
      const tipo = data.tipo_contrato;
      const artistaId = data.artista_id_contrato;
      if(!tipo) return alert("❌ Debes seleccionar tipo de contrato");
      if(!artistaId) return alert("❌ Debes ingresar el ID del artista");
      if(tipo === "solista") data.solista_id = parseInt(artistaId);
      else if(tipo === "banda") data.banda_id = parseInt(artistaId);
      delete data.artista_id_contrato;
      delete data.tipo_contrato;
    }

    if (endpoint === "turnos") {
      const tipo = data.tipo_artista;
      const artistaId = data.artista_id;
      if (!tipo || !artistaId) return alert("❌ Debes seleccionar tipo de artista y su ID");
      if (tipo === "solista") data.solista_id = parseInt(artistaId);
      else if (tipo === "banda") data.banda_id = parseInt(artistaId);
      delete data.tipo_artista;
      delete data.artista_id;
    }

    // Envío
    try {
      const res = await fetch(`${API}/${endpoint}`, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(data)
      });
      const result = await res.json();
      if (!res.ok) return alert(`❌ Error: ${result.error || "Desconocido"}`);
      alert("✅ Registro creado correctamente");
      form.reset();
      fetchAndRender(endpoint, endpoint);
    } catch (err) {
      alert("❌ Error creando registro");
      console.error(err);
    }
  });
}

// ------------------- ELIMINAR -------------------
async function deleteRecord(endpoint, id) {
  if (!confirm("¿Seguro que deseas eliminar este registro?")) return;
  try {
    const res = await fetch(`${API}/${endpoint}/${id}`, { method: "DELETE" });
    const result = await res.json();
    if (!res.ok) return alert(`Error al eliminar: ${result.error || "Desconocido"}`);
    alert("Registro eliminado correctamente");
    fetchAndRender(endpoint, endpoint);
  } catch (err) {
    alert("Error al eliminar");
    console.error(err);
  }
}

// ------------------- EDITAR -------------------
async function editRecord(endpoint, id) {
  const newData = prompt("Introduce los nuevos valores en formato JSON.\nEjemplo: {\"nombre\": \"Nuevo nombre\"}");
  if (!newData) return;
  try {
    const parsed = JSON.parse(newData);
    const res = await fetch(`${API}/${endpoint}/${id}`, {
      method: "PUT",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(parsed)
    });
    const result = await res.json();
    if (!res.ok) return alert(`Error: ${result.error || "Desconocido"}`);
    alert("Registro actualizado correctamente");
    fetchAndRender(endpoint, endpoint);
  } catch (err) {
    alert("Error formato JSON o actualización");
    console.error(err);
  }
}

// ------------------- FILTRAR TURNOS -------------------
async function filtrarTurnosPorEvento() {
  const eventoId = document.getElementById("buscar-evento-id").value;
  if (!eventoId) return alert("Ingrese un ID de evento");
  try {
    const res = await fetch(`${API}/turnos/evento/${eventoId}`);
    const data = await res.json();
    const table = document.getElementById("table-turnos");
    if (!Array.isArray(data) || data.length === 0) {
      table.innerHTML = "<tr><td>No hay turnos para este evento</td></tr>";
      return;
    }
    const headers = columnOrder.turnos;
    table.innerHTML = `
      <tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr>
      ${data.map(row=>`<tr>${headers.map(h=>`<td>${row[h]||""}</td>`).join("")}</tr>`).join("")}
    `;
  } catch (err) {
    alert("Error filtrando turnos");
    console.error(err);
  }
}

// ------------------- INICIALIZAR -------------------
const entidades = ["disqueras","solistas","bandas","albumes","canciones","eventos","contratos","turnos"];
entidades.forEach(ent => {
  let formId = ent==="albumes"?"form-album":ent==="canciones"?"form-cancion":`form-${ent.slice(0,-1)}`;
  setupForm(formId, ent);
});
entidades.forEach(ent => fetchAndRender(ent, ent));
