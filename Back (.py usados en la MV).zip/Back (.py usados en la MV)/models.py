from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# ---------------------- TABLAS INTERMEDIAS ----------------------

# Renombradas según tu solicitud
Producir = db.Table(
    'Producir',
    db.Column('album_id', db.Integer, db.ForeignKey('Album.album_id', ondelete='CASCADE'), primary_key=True),
    db.Column('contrato_id', db.Integer, db.ForeignKey('Contrato.contrato_id', ondelete='CASCADE'), primary_key=True)
)

FirmarB = db.Table(
    'FirmarB',
    db.Column('banda_id', db.Integer, db.ForeignKey('Banda.banda_id', ondelete='CASCADE'), primary_key=True),
    db.Column('disquera_id', db.Integer, db.ForeignKey('Disquera.disquera_id', ondelete='CASCADE'), primary_key=True)
)

PresentarB = db.Table(
    'PresentarB',
    db.Column('banda_id', db.Integer, db.ForeignKey('Banda.banda_id', ondelete='CASCADE'), primary_key=True),
    db.Column('evento_id', db.Integer, db.ForeignKey('Evento.evento_id', ondelete='CASCADE'), primary_key=True)
)

Firmar = db.Table(
    'Firmar',
    db.Column('solista_id', db.Integer, db.ForeignKey('Solista.solista_id', ondelete='CASCADE'), primary_key=True),
    db.Column('disquera_id', db.Integer, db.ForeignKey('Disquera.disquera_id', ondelete='CASCADE'), primary_key=True)
)

Presentar = db.Table(
    'Presentar',
    db.Column('solista_id', db.Integer, db.ForeignKey('Solista.solista_id', ondelete='CASCADE'), primary_key=True),
    db.Column('evento_id', db.Integer, db.ForeignKey('Evento.evento_id', ondelete='CASCADE'), primary_key=True)
)

# ---------------------- DISQUERA ----------------------
class Disquera(db.Model):
    __tablename__ = 'Disquera'
    disquera_id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    ciudad_sede = db.Column(db.String(100))
    telefono = db.Column(db.String(50))

    albumes = db.relationship('Album', backref='disquera', lazy=True, cascade="all, delete")
    contratos = db.relationship('Contrato', backref='disquera', lazy=True, cascade="all, delete")

    # Relaciones M:N
    bandas = db.relationship('Banda', secondary=FirmarB, back_populates='disqueras', cascade="all, delete")
    solistas = db.relationship('Solista', secondary=Firmar, back_populates='disqueras', cascade="all, delete")

# ---------------------- SOLISTA ----------------------
class Solista(db.Model):
    __tablename__ = 'Solista'
    solista_id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)       # Antes era nombre_real
    apellido = db.Column(db.String(100))                     # Nueva columna
    nombre_artistico = db.Column(db.String(100))
    sexo = db.Column(db.String(20))
    fecha_nacimiento = db.Column(db.Date)
    inicio_carrera = db.Column(db.Date)
    ciudad_nacimiento = db.Column(db.String(100))

    # Relaciones 1:N
    albumes = db.relationship('Album', backref='solista', lazy=True, cascade="all, delete")
    contratos = db.relationship('Contrato', backref='solista', lazy=True, cascade="all, delete")
    turnos = db.relationship('Turno', backref='solista', lazy=True, cascade="all, delete")

    # Relaciones M:N
    disqueras = db.relationship('Disquera', secondary=Firmar, back_populates='solistas', cascade="all, delete")
    eventos = db.relationship('Evento', secondary=Presentar, back_populates='solistas', cascade="all, delete")

# ---------------------- BANDA ----------------------
class Banda(db.Model):
    __tablename__ = 'Banda'
    banda_id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    anio_formacion = db.Column(db.Integer)
    num_integrantes = db.Column(db.Integer)
    representante = db.Column(db.String(100))

    albumes = db.relationship('Album', backref='banda', lazy=True, cascade="all, delete")
    turnos = db.relationship('Turno', backref='banda', lazy=True, cascade="all, delete")

    # Relaciones M:N
    disqueras = db.relationship('Disquera', secondary=FirmarB, back_populates='bandas', cascade="all, delete")
    eventos = db.relationship('Evento', secondary=PresentarB, back_populates='bandas', cascade="all, delete")

# ---------------------- ÁLBUM ----------------------
class Album(db.Model):
    __tablename__ = 'Album'
    album_id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100), nullable=False)
    anio = db.Column(db.Integer)
    genero = db.Column(db.String(50))
    duracion_total = db.Column(db.Time, nullable=True)

    disquera_id = db.Column(db.Integer, db.ForeignKey('Disquera.disquera_id', ondelete='CASCADE'))
    solista_id = db.Column(db.Integer, db.ForeignKey('Solista.solista_id', ondelete='CASCADE'), nullable=True)
    banda_id = db.Column(db.Integer, db.ForeignKey('Banda.banda_id', ondelete='CASCADE'), nullable=True)

    canciones = db.relationship('Cancion', backref='album', lazy=True, cascade="all, delete")

    # Relación M:N con contratos
    contratos = db.relationship('Contrato', secondary=Producir, back_populates='albumes', cascade="all, delete")

# ---------------------- CANCIÓN ----------------------
class Cancion(db.Model):
    __tablename__ = 'Cancion'
    cancion_id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100), nullable=False)
    duracion_seconds = db.Column(db.Integer)
    idioma = db.Column(db.String(50))

    album_id = db.Column(db.Integer, db.ForeignKey('Album.album_id', ondelete='CASCADE'))

# ---------------------- EVENTO ----------------------
class Evento(db.Model):
    __tablename__ = 'Evento'
    evento_id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    fecha = db.Column(db.Date)
    lugar = db.Column(db.String(100))
    horario_inicio = db.Column(db.Time)
    horario_fin = db.Column(db.Time)

    turnos = db.relationship('Turno', backref='evento', lazy=True, cascade="all, delete")

    # Relaciones M:N
    bandas = db.relationship('Banda', secondary=PresentarB, back_populates='eventos', cascade="all, delete")
    solistas = db.relationship('Solista', secondary=Presentar, back_populates='eventos', cascade="all, delete")

# ---------------------- CONTRATO ----------------------
class Contrato(db.Model):
    __tablename__ = 'Contrato'
    contrato_id = db.Column(db.Integer, primary_key=True)
    solista_id = db.Column(db.Integer, db.ForeignKey('Solista.solista_id', ondelete='CASCADE'), nullable=True)
    disquera_id = db.Column(db.Integer, db.ForeignKey('Disquera.disquera_id', ondelete='CASCADE'))
    fecha_inicio = db.Column(db.Date)
    fecha_fin = db.Column(db.Date)
    condiciones = db.Column(db.Text)
    banda_id = db.Column(db.Integer, db.ForeignKey('Banda.banda_id', ondelete='CASCADE'), nullable=True)

    # Relación M:N con álbumes
    albumes = db.relationship('Album', secondary=Producir, back_populates='contratos', cascade="all, delete")

# ---------------------- TURNO ----------------------
class Turno(db.Model):
    __tablename__ = 'Turno'
    turno_id = db.Column(db.Integer, primary_key=True)
    evento_id = db.Column(db.Integer, db.ForeignKey('Evento.evento_id', ondelete='CASCADE'))
    solista_id = db.Column(db.Integer, db.ForeignKey('Solista.solista_id', ondelete='CASCADE'), nullable=True)
    banda_id = db.Column(db.Integer, db.ForeignKey('Banda.banda_id', ondelete='CASCADE'), nullable=True)
    orden_presentacion = db.Column(db.Integer)
    fecha = db.Column(db.Date)
    hora_inicio = db.Column(db.Time)
    hora_fin = db.Column(db.Time)
    lugar = db.Column(db.String(100))

