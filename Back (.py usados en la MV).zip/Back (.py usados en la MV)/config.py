# config.py

# Configuración de conexión a MySQL (XAMPP)
# -----------------------------------------
# Usuario: root
# Contraseña: (vacía)
# Base de datos: dulcinea
# Puerto: 3306
# Host: localhost

SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root@localhost:3306/dulcinea-proyecto"
SQLALCHEMY_TRACK_MODIFICATIONS = False
DEBUG = True
