from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from models import db, Disquera, Solista, Banda, Album, Cancion, Evento, Contrato, Turno
from datetime import date, datetime, time
from sqlalchemy import func
import config

app = Flask(__name__)
CORS(app)
app.config.from_object(config)
db.init_app(app)

# ---------------------- UTILIDADES ----------------------

def serialize(model):
    data = model.__dict__.copy()
    data.pop("_sa_instance_state", None)
    for k, v in data.items():
        if isinstance(v, (datetime, date)):
            data[k] = v.isoformat()
        elif isinstance(v, time):
            data[k] = v.strftime("%H:%M:%S")
    return data

def get_all(model):
    return jsonify([serialize(row) for row in model.query.all()])

def create(model, data):
    try:
        obj = model(**data)
        db.session.add(obj)
        db.session.commit()
        return jsonify({"status": "ok", "id": getattr(obj, list(model.__table__.primary_key.columns)[0].name)})
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

def update(model, id_field, id, data):
    obj = model.query.filter(getattr(model, id_field) == id).first()
    if not obj:
        return jsonify({"error": "No encontrado"}), 404
    for key, value in data.items():
        setattr(obj, key, value)
    db.session.commit()
    return jsonify({"status": "actualizado", "id": id})

def delete(model, id_field, id):
    obj = model.query.filter(getattr(model, id_field) == id).first()
    if not obj:
        return jsonify({"error": "No encontrado"}), 404
    db.session.delete(obj)
    db.session.commit()
    return jsonify({"status": "eliminado", "id": id})

# ---------------------- FUNCIONES DE RECONCILIACIÓN ----------------------

def reconciliar_album_contrato(album=None, contrato=None):
    """Llena Producir automáticamente."""
    albums = [album] if album else Album.query.all()
    contratos = [contrato] if contrato else Contrato.query.all()

    for alb in albums:
        for con in contratos:
            if con not in alb.contratos:
                if alb.solista_id and con.solista_id == alb.solista_id:
                    alb.contratos.append(con)
                elif alb.disquera_id and con.disquera_id == alb.disquera_id:
                    alb.contratos.append(con)
    db.session.commit()

def reconciliar_solista_disquera(solista=None, disquera=None, contrato=None):
    """Llena Firmar automáticamente."""
    contratos = [contrato] if contrato else Contrato.query.all()
    for con in contratos:
        if con.solista_id and con.disquera_id:
            sol = Solista.query.get(con.solista_id)
            disq = Disquera.query.get(con.disquera_id)
            if sol and disq and disq not in sol.disqueras:
                sol.disqueras.append(disq)
    db.session.commit()

def reconciliar_banda_disquera(banda=None, disquera=None, contrato=None):
    """Llena FirmarB automáticamente usando banda_id en contratos."""
    contratos = [contrato] if contrato else Contrato.query.filter(Contrato.banda_id.isnot(None)).all()
    for con in contratos:
        b = Banda.query.get(con.banda_id)
        d = Disquera.query.get(con.disquera_id)
        if b and d and b not in d.bandas:
            d.bandas.append(b)
    db.session.commit()

def reconciliar_evento(evento=None):
    """Llena Presentar y PresentarB automáticamente para todos los eventos o un evento específico."""
    eventos = [evento] if evento else Evento.query.all()
    for ev in eventos:
        # Presentar: solistas-evento
        for sol in Solista.query.all():
            # Si el solista tiene al evento en su lista de turnos o álbumes, se asume relación
            if sol not in ev.solistas:
                # Revisar si existe algún Turno o Album que conecte el solista con el evento
                turnos = Turno.query.filter_by(solista_id=sol.solista_id, evento_id=ev.evento_id).all()
                if turnos:
                    ev.solistas.append(sol)
        # PresentarB: bandas-evento
        for b in Banda.query.all():
            if b not in ev.bandas:
                turnos = Turno.query.filter_by(banda_id=b.banda_id, evento_id=ev.evento_id).all()
                if turnos:
                    ev.bandas.append(b)
    db.session.commit()
    
    # ------------------- FUNCION: RECALCULAR DURACION ALBUM -------------------
def recalcular_duracion_album(album_id):
    """
    Suma todas las duraciones (duracion_seconds) de las canciones
    del álbum y guarda el resultado en Album.duracion_total (tipo time).
    Si no hay canciones, deja duracion_total en None.
    """
    if not album_id:
        return

    # Sumar duracion_seconds de todas las canciones del album
    total_seconds = db.session.query(func.coalesce(func.sum(Cancion.duracion_seconds), 0)).filter(Cancion.album_id == album_id).scalar() or 0

    if total_seconds == 0:
        # No hay canciones -> limpiar duracion_total
        album = Album.query.get(album_id)
        if album:
            album.duracion_total = None
            db.session.commit()
        return

    # Convertir segundos a HH:MM:SS
    hrs, rem = divmod(int(total_seconds), 3600)
    mins, secs = divmod(rem, 60)
    # Asegurarnos de que hour < 24 (time requiere 0-23). Si pasara >23h, lo truncamos con modulo 24
    dur_time = time(hour=(hrs % 24), minute=mins, second=secs)

    album = Album.query.get(album_id)
    if album:
        album.duracion_total = dur_time
        db.session.commit()
        
# ---------------------- RUTAS ----------------------
@app.route('/')
def home():
    return jsonify({"message": "✅ API Dulcinea funcionando correctamente"})

# ---------- DISQUERAS ----------
@app.route('/disqueras', methods=['GET', 'POST'])
def disqueras():
    if request.method == 'GET':
        return get_all(Disquera)
    res = create(Disquera, request.json)
    reconciliar_banda_disquera(disquera=Disquera.query.get(request.json.get('disquera_id')))
    return res

@app.route('/disqueras/<int:id>', methods=['PUT', 'DELETE'])
def disquera_by_id(id):
    if request.method == 'PUT':
        return update(Disquera, 'disquera_id', id, request.json)
    return delete(Disquera, 'disquera_id', id)

# ---------- SOLISTAS ----------
@app.route('/solistas', methods=['GET', 'POST'])
def solistas():
    if request.method == 'GET':
        return get_all(Solista)

    data = request.json or {}

    # Validaciones obligatorias
    if not data.get("nombre") or not data.get("apellido"):
        return jsonify({"error": "Nombre y apellido son obligatorios"}), 400

    # Crear solista
    res = create(Solista, data)

    # Reconciliación automática con disqueras
    solista_id = data.get('solista_id') or (res.json.get('id') if hasattr(res, 'json') else None)
    if solista_id:
        reconciliar_solista_disquera(solista=Solista.query.get(solista_id))

    return res

@app.route('/solistas/<int:id>', methods=['PUT', 'DELETE'])
def solista_by_id(id):
    if request.method == 'PUT':
        data = request.json or {}
        # Validaciones obligatorias
        if ("nombre" in data and not data["nombre"]) or ("apellido" in data and not data["apellido"]):
            return jsonify({"error": "Nombre y apellido no pueden estar vacíos"}), 400

        res = update(Solista, 'solista_id', id, data)

        # Reconciliación automática con disqueras
        reconciliar_solista_disquera(solista=Solista.query.get(id))
        return res

    return delete(Solista, 'solista_id', id)

# ---------- BANDAS ----------
@app.route('/bandas', methods=['GET', 'POST'])
def bandas():
    if request.method == 'GET':
        return get_all(Banda)
    res = create(Banda, request.json)
    reconciliar_banda_disquera(banda=Banda.query.get(request.json.get('banda_id')))
    return res

@app.route('/bandas/<int:id>', methods=['PUT', 'DELETE'])
def banda_by_id(id):
    if request.method == 'PUT':
        return update(Banda, 'banda_id', id, request.json)
    return delete(Banda, 'banda_id', id)

# ---------- ALBUMES ----------
@app.route('/albumes', methods=['GET', 'POST'])
def albumes():
    if request.method == 'GET':
        return get_all(Album)

    data = request.get_json()
    solista_id = data.get('solista_id')
    banda_id = data.get('banda_id')
    solista_id = int(solista_id) if solista_id not in [None, '', 'null'] else None
    banda_id = int(banda_id) if banda_id not in [None, '', 'null'] else None
    if solista_id and banda_id:
        return jsonify({'error': 'El álbum no puede pertenecer a un solista y una banda a la vez'}), 400
    if not solista_id and not banda_id:
        return jsonify({'error': 'Debe seleccionar un solista o una banda'}), 400

    nuevo_album = Album(
        titulo=data['titulo'],
        anio=data['anio'],
        genero=data['genero'],
        duracion_total=None,
        disquera_id=data['disquera_id'],
        solista_id=solista_id,
        banda_id=banda_id
    )
    db.session.add(nuevo_album)
    db.session.commit()
    reconciliar_album_contrato(album=nuevo_album)
    return jsonify({'message': 'Álbum creado con éxito', 'album_id': nuevo_album.album_id})

@app.route('/albumes/<int:id>', methods=['PUT', 'DELETE'])
def album_by_id(id):
    if request.method == 'PUT':
        data = request.get_json()
        res = update(Album, 'album_id', id, data)
        reconciliar_album_contrato(album=Album.query.get(id))
        return res
    return delete(Album, 'album_id', id)

# ---------- CANCIONES ----------
@app.route('/canciones', methods=['GET', 'POST'])
def canciones():
    if request.method == 'GET':
        return get_all(Cancion)

    # POST: Crear canción y recalcular duración del álbum si aplica
    data = request.json or {}
    # Validación de duración (si envían en segundos)
    duracion = data.get("duracion_seconds")
    if duracion is not None:
        try:
            duracion = int(duracion)
            if duracion > 600:
                return jsonify({"error": "La duración máxima permitida es de 10 minutos (600 segundos)."}), 400
            data['duracion_seconds'] = duracion
        except ValueError:
            return jsonify({"error": "La duración debe ser un número en segundos."}), 400

    # Crear la canción usando tu helper
    res = create(Cancion, data)

    # Si se creó correctamente, extraer id del album y recalcular
    try:
        # obtener album_id desde payload (si existe)
        album_id = data.get('album_id')
        if album_id:
            recalcular_duracion_album(int(album_id))
    except Exception:
        pass

    return res

@app.route('/canciones/<int:id>', methods=['PUT', 'DELETE'])
def cancion_by_id(id):
    # PUT: actualizar canción y recalcular duración del álbum (si cambia album_id o duracion_seconds)
    if request.method == 'PUT':
        data = request.json or {}

        # Antes de actualizar, obtener album_id antiguo para recalcular después
        cancion_actual = Cancion.query.filter_by(cancion_id=id).first()
        old_album_id = cancion_actual.album_id if cancion_actual else None

        # Validar duracion si la envían
        if 'duracion_seconds' in data and data['duracion_seconds'] is not None:
            try:
                data['duracion_seconds'] = int(data['duracion_seconds'])
                if data['duracion_seconds'] > 600:
                    return jsonify({"error": "La duración máxima permitida es de 10 minutos (600 segundos)."}), 400
            except ValueError:
                return jsonify({"error": "La duración debe ser un número en segundos."}), 400

        res = update(Cancion, 'cancion_id', id, data)

        # Recalcular para álbum viejo y nuevo (si cambió album_id)
        try:
            # album id nuevo puede venir en data; sino usar old_album_id
            new_album_id = data.get('album_id', old_album_id)
            if old_album_id:
                recalcular_duracion_album(old_album_id)
            if new_album_id and new_album_id != old_album_id:
                recalcular_duracion_album(new_album_id)
        except Exception:
            pass

        return res

    # DELETE: borrar canción y recalcular duración del álbum asociado
    # Obtener album_id antes de borrar
    cancion = Cancion.query.filter_by(cancion_id=id).first()
    album_id = cancion.album_id if cancion else None

    res = delete(Cancion, 'cancion_id', id)

    # Recalcular si había álbum asociado
    if album_id:
        try:
            recalcular_duracion_album(album_id)
        except Exception:
            pass

    return res

# ---------- EVENTOS ----------
@app.route('/eventos', methods=['GET', 'POST'])
def eventos():
    if request.method == 'GET':
        return get_all(Evento)

    data = request.json
    nuevo_evento = Evento(
        nombre=data['nombre'],
        fecha=data['fecha'],
        lugar=data['lugar'],
        horario_inicio=data['horario_inicio'],
        horario_fin=data['horario_fin']
    )
    db.session.add(nuevo_evento)
    db.session.commit()

    # Relaciones automáticas desde JSON
    for solista_id in data.get('solistas', []):
        solista = Solista.query.get(solista_id)
        if solista and solista not in nuevo_evento.solistas:
            nuevo_evento.solistas.append(solista)
    for banda_id in data.get('bandas', []):
        banda = Banda.query.get(banda_id)
        if banda and banda not in nuevo_evento.bandas:
            nuevo_evento.bandas.append(banda)
    db.session.commit()

    # Reconciliación automática Presentar y PresentarB
    reconciliar_evento(evento=nuevo_evento)

    return jsonify({'message': 'Evento creado con éxito', 'evento_id': nuevo_evento.evento_id})

@app.route('/eventos/<int:id>', methods=['PUT', 'DELETE'])
def evento_by_id(id):
    if request.method == 'PUT':
        res = update(Evento, 'evento_id', id, request.json)
        reconciliar_evento(evento=Evento.query.get(id))
        return res
    return delete(Evento, 'evento_id', id)

# ---------- CONTRATOS ----------
@app.route('/contratos', methods=['GET', 'POST'])
def contratos():
    if request.method == 'GET':
        return get_all(Contrato)

    data = request.get_json()

    solista_id = data.get('solista_id')
    banda_id = data.get('banda_id')
    disquera_id = data.get('disquera_id')

    # Validación: no puede tener solista y banda al mismo tiempo
    if solista_id and banda_id:
        return jsonify({"error": "El contrato no puede pertenecer a un solista y a una banda a la vez."}), 400
    if not solista_id and not banda_id:
        return jsonify({"error": "Debe asignar un solista o una banda al contrato."}), 400

    nuevo_contrato = Contrato(
        solista_id=solista_id,
        banda_id=banda_id,
        disquera_id=disquera_id,
        fecha_inicio=data['fecha_inicio'],
        fecha_fin=data['fecha_fin'],
        condiciones=data['condiciones']
    )
    db.session.add(nuevo_contrato)
    db.session.commit()

    # Reconciliación automática:
    # Si es solista, llena Firmar
    if solista_id:
        reconciliar_solista_disquera(contrato=nuevo_contrato)
    # Si es banda, llena FirmarB
    if banda_id:
        reconciliar_banda_disquera(banda=Banda.query.get(banda_id), disquera=Disquera.query.get(disquera_id))

    # También actualiza Producir si aplica
    reconciliar_album_contrato()

    return jsonify({'message': 'Contrato creado con éxito', 'contrato_id': nuevo_contrato.contrato_id})


@app.route('/contratos/<int:id>', methods=['PUT', 'DELETE'])
def contrato_by_id(id):
    if request.method == 'PUT':
        data = request.get_json()

        solista_id = data.get('solista_id')
        banda_id = data.get('banda_id')
        disquera_id = data.get('disquera_id')

        # Validación: no puede tener solista y banda al mismo tiempo
        if solista_id and banda_id:
            return jsonify({"error": "El contrato no puede pertenecer a un solista y a una banda a la vez."}), 400
        if not solista_id and not banda_id:
            return jsonify({"error": "Debe asignar un solista o una banda al contrato."}), 400

        res = update(Contrato, 'contrato_id', id, data)

        # Reconciliación automática:
        contrato_actual = Contrato.query.get(id)
        if contrato_actual.solista_id:
            reconciliar_solista_disquera(contrato=contrato_actual)
        if contrato_actual.banda_id:
            reconciliar_banda_disquera(banda=Banda.query.get(contrato_actual.banda_id),
                                       disquera=Disquera.query.get(contrato_actual.disquera_id))

        reconciliar_album_contrato()

        return res

    return delete(Contrato, 'contrato_id', id)

# ---------- TURNOS ----------
@app.route('/turnos', methods=['GET', 'POST'])
def turnos():
    if request.method == 'GET':
        return get_all(Turno)

    data = request.json or {}
    solista_id = data.get("solista_id")
    banda_id = data.get("banda_id")
    evento_id = data.get("evento_id")  
    orden_presentacion = data.get("orden_presentacion")

    if solista_id and banda_id:
        return jsonify({"error": "Un turno no puede asignarse a un solista y a una banda al mismo tiempo."}), 400
    if not solista_id and not banda_id:
        return jsonify({"error": "El turno debe pertenecer a un solista o a una banda."}), 400

    turno_existente = Turno.query.filter_by(evento_id=evento_id, orden_presentacion=orden_presentacion).first()
    if turno_existente:
        return jsonify({'error': f'Ya existe un turno con orden {orden_presentacion} en este evento'}), 400

    turno = Turno(**data)
    db.session.add(turno)
    db.session.commit()

    # Relación automática con canciones
    for cancion_id in data.get('canciones', []):
        cancion = Cancion.query.get(cancion_id)
        if cancion:
            turno.canciones.append(cancion)
    db.session.commit()

    return jsonify({"mensaje": "Turno creado correctamente", "turno_id": turno.turno_id})

@app.route('/turnos/<int:id>', methods=['PUT', 'DELETE'])
def turno_by_id(id):
    if request.method == 'PUT':
        return update(Turno, 'turno_id', id, request.json)
    return delete(Turno, 'turno_id', id)

# ---------------------- MAIN ----------------------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Reconciliar todo al inicio por si ya existen registros
        reconciliar_album_contrato()
        reconciliar_solista_disquera()
        reconciliar_banda_disquera()
        reconciliar_evento()
    app.run(host='0.0.0.0', port=5000, debug=True)

