CREATE TABLE Evento (
    evento_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    fecha DATE,
    lugar VARCHAR(100),
    horario_inicio TIME,
    horario_fin TIME
);