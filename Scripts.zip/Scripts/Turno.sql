CREATE TABLE Turno (
    turno_id INT AUTO_INCREMENT PRIMARY KEY,
    evento_id INT NOT NULL,
    solista_id INT,
    banda_id INT,
    orden_presentacion INT,
    fecha DATE,
    hora_inicio TIME,
    hora_fin TIME,
    lugar VARCHAR(100),
    FOREIGN KEY(solista_id) REFERENCES Solista(solista_id) ON DELETE CASCADE,
    FOREIGN KEY(banda_id) REFERENCES Banda(banda_id) ON DELETE CASCADE
);