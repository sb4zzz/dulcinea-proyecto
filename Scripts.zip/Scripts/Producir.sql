CREATE TABLE Producir (
    contrato_id INT NOT NULL,
    album_id INT NOT NULL,
    PRIMARY KEY (contrato_id, album_id),
    FOREIGN KEY (contrato_id) REFERENCES Contrato(id) ON DELETE CASCADE,
    FOREIGN KEY (album_id) REFERENCES Album(id) ON DELETE CASCADE
);