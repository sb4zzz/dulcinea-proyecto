CREATE TABLE Contrato (
    contrato_id INT AUTO_INCREMENT PRIMARY KEY,
    solista_id INT,
    disquera_id INT,
    fecha_inicio DATE,
    fecha_fin DATE,
    condiciones TEXT,
    banda_id INT,
    FOREIGN KEY(solista_id) REFERENCES Solista(solista_id) ON DELETE CASCADE,
    FOREIGN KEY(banda_id) REFERENCES Banda(banda_id) ON DELETE CASCADE,
    FOREIGN KEY(disquera_id) REFERENCES Disquera(disquera_id) ON DELETE CASCADE
);