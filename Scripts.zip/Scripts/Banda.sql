CREATE TABLE Banda (
    banda_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    anio_formacion YEAR,
    num_integrantes INT,
    representante VARCHAR(100)
);