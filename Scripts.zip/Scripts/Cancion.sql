CREATE TABLE Cancion (
    cancion_id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    duracion_seconds INT,
    idioma VARCHAR(50),
    album_id INT,
    FOREIGN KEY (album_id) REFERENCES Album(album_id) ON DELETE CASCADE
);
