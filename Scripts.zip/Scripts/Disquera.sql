CREATE TABLE Disquera (
    disquera_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ciudad_sede VARCHAR(100),
    telefono VARCHAR(50)
);